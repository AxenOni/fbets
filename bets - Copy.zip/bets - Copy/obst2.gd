extends StaticBody2D

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == 'player':
		if body.scale.x > 1.13:
			queue_free()


#func _on_area_2d_area_entered(area: Area2D) -> void:
	#if area.is_in_group("player"):
		#print("destroy!")
